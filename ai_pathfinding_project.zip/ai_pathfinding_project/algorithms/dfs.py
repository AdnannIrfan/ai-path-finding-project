

def dfs(graph, start, goal, **kwargs):
    """
    DFS that supports frontend format:
    graph[node] = [ {"node": "A", "weight": 1}, ... ]
    """

    
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    stack = [start]
    visited = []
    parent = {start: None}

    while stack:
        node = stack.pop()

        if node not in visited:
            visited.append(node)

            if node == goal:
                break

            for neighbor in reversed(clean_graph.get(node, [])):
                if neighbor not in visited:
                    parent[neighbor] = node
                    stack.append(neighbor)

   
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = parent.get(current)

    path.reverse()

    return {
        "path": path,
        "visited": visited,
        "steps": len(visited),
        "cost": None
    }
