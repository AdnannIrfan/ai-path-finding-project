import heapq

def greedy_best_first(graph, start, goal, heuristic, **kwargs):
    pq = [(heuristic(start, goal), start, [start])]
    visited = set()
    visit_order = []

    while pq:
        h, node, path = heapq.heappop(pq)

        if node == goal:
            visit_order.append(node)
            return {
                "path": path,
                "visited": visit_order,
                "steps": len(visit_order),
                "cost": None
            }

        if node in visited:
            continue

        visited.add(node)
        visit_order.append(node)

        for neighbor, _ in graph.get(node, []):
            if neighbor not in visited:
                heapq.heappush(pq, (heuristic(neighbor, goal), neighbor, path + [neighbor]))

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }

