

def bfs(graph, start, goal, **kwargs):
    """
    BFS that supports frontend format:
    graph[node] = [ {"node": "A", "weight": 1}, ... ]
    """

    
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    visited = []
    queue = [start]
    parent = {start: None}

    while queue:
        node = queue.pop(0)
        visited.append(node)

        if node == goal:
            break

        for n in clean_graph.get(node, []):
            if n not in visited and n not in queue:
                parent[n] = node
                queue.append(n)

   
    path = []
    node = goal
    while node is not None:
        path.append(node)
        node = parent.get(node)
    path.reverse()

    return {
        "path": path,
        "visited": visited,
        "steps": len(visited),
        "cost": None
    }
