
import heapq

def beam_search(graph, start, goal, heuristic, beam_width=2, **kwargs):
    """
    Beam Search compatible with frontend graph JSON:
    graph[node] = [ {"node": "B", "weight": 3}, ... ]
    """

    
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    states = [(heuristic(start, goal), start, [start])]
    visited = set([start])
    visit_order = [start]

    while states:
        new_states = []

        for _, node, path in states:
            if node == goal:
                return {
                    "path": path,
                    "visited": visit_order,
                    "steps": len(visit_order),
                    "cost": None
                }

            for neighbor in clean_graph.get(node, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    visit_order.append(neighbor)
                    new_states.append((heuristic(neighbor, goal), neighbor, path + [neighbor]))

        
        states = heapq.nsmallest(beam_width, new_states)

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }
