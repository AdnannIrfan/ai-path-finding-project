

def dls(graph, node, goal, depth, path, visited):
    if depth == 0:
        if node == goal:
            return path
        return None

    for neighbor in graph.get(node, []):
        if neighbor not in visited:
            visited.add(neighbor)
            result = dls(graph, neighbor, goal, depth - 1, path + [neighbor], visited)
            if result:
                return result

    return None

def iddfs(graph, start, goal, max_depth=20, **kwargs):
    """
    Iterative Deepening DFS compatible with frontend graph JSON:
    graph[node] = [ {"node": "B", "weight": 3}, ... ]
    """

    
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    visit_order = []

    for depth in range(max_depth):
        visited = set([start])
        result = dls(clean_graph, start, goal, depth, [start], visited)
        visit_order.extend(list(visited))
        if result:
            return {
                "path": result,
                "visited": list(visit_order),
                "steps": len(visit_order),
                "cost": None
            }

    return {
        "path": None,
        "visited": list(visit_order),
        "steps": len(visit_order),
        "cost": None
    }
