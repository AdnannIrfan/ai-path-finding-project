import heapq

def ucs(graph, start, goal, **kwargs):
    pq = [(0, start, [start])]
    visited = set()
    visit_order = []

    while pq:
        cost, node, path = heapq.heappop(pq)

        if node == goal:
            visit_order.append(node)
            return {
                "path": path,
                "visited": visit_order,
                "steps": len(visit_order),
                "cost": cost
            }

        if node in visited:
            continue

        visited.add(node)
        visit_order.append(node)

        for neighbor, weight in graph.get(node, []):
            if neighbor not in visited:
                heapq.heappush(pq, (cost + weight, neighbor, path + [neighbor]))

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }
