import heapq

def dijkstra(graph, start, goal, **kwargs):
    pq = [(0, start, [start])]
    distances = {start: 0}
    visited = set()
    visit_order = []

    while pq:
        dist, node, path = heapq.heappop(pq)

        if node == goal:
            visit_order.append(node)
            return {
                "path": path,
                "visited": visit_order,
                "steps": len(visit_order),
                "cost": dist
            }

        if node in visited:
            continue

        visited.add(node)
        visit_order.append(node)

        for neighbor, weight in graph.get(node, []):
            new_dist = dist + weight
            if neighbor not in distances or new_dist < distances[neighbor]:
                distances[neighbor] = new_dist
                heapq.heappush(pq, (new_dist, neighbor, path + [neighbor]))

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }

