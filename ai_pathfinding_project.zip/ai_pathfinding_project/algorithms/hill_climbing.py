

def hill_climbing(graph, start, goal, heuristic, **kwargs):
    """
    Hill Climbing compatible with frontend graph JSON:
    graph[node] = [ {"node": "B", "weight": 3}, ... ]
    """

   
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    current = start
    path = [start]
    visited = set([start])

    while current != goal:
        neighbors = clean_graph.get(current, [])
        if not neighbors:
            return {
                "path": None,
                "visited": list(visited),
                "steps": len(visited),
                "cost": None
            }

        
        best_neighbor = min(neighbors, key=lambda x: heuristic(x, goal))

        
        if heuristic(best_neighbor, goal) >= heuristic(current, goal):
            return {
                "path": None,
                "visited": list(visited),
                "steps": len(visited),
                "cost": None
            }

        current = best_neighbor
        path.append(current)
        visited.add(current)

    return {
        "path": path,
        "visited": list(visited),
        "steps": len(visited),
        "cost": None
    }
