import heapq

def astar(graph, start, goal, heuristic, **kwargs):
    pq = [(0, start, [start])]
    visited = set()
    g_cost = {start: 0}
    visit_order = []

    while pq:
        f, node, path = heapq.heappop(pq)

        if node == goal:
            visit_order.append(node)
            return {
                "path": path,
                "visited": visit_order,
                "steps": len(visit_order),
                "cost": g_cost[node]
            }

        if node in visited:
            continue

        visited.add(node)
        visit_order.append(node)

        for neighbor, weight in graph.get(node, []):
            new_cost = g_cost[node] + weight
            if neighbor not in g_cost or new_cost < g_cost[neighbor]:
                g_cost[neighbor] = new_cost
                f_cost = new_cost + heuristic(neighbor, goal)
                heapq.heappush(pq, (f_cost, neighbor, path + [neighbor]))

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }
