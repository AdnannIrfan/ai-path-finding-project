
from collections import deque

def bidirectional_search(graph, start, goal, **kwargs):
    """
    Bidirectional Search compatible with frontend graph JSON:
    graph[node] = [ {"node": "B", "weight": 3}, ... ]
    """

    
    clean_graph = {}
    for node, edges in graph.items():
        clean_graph[node] = [e["node"] if isinstance(e, dict) else e for e in edges]

    if start == goal:
        return {
            "path": [start],
            "visited": [start],
            "steps": 1,
            "cost": None
        }

    front = {start: None}
    back = {goal: None}
    queue_f = deque([start])
    queue_b = deque([goal])
    visited = set([start, goal])
    visit_order = [start, goal]

    meet_node = None

    while queue_f and queue_b:
      
        f = queue_f.popleft()
        for neigh in clean_graph.get(f, []):
            if neigh not in front:
                front[neigh] = f
                queue_f.append(neigh)
                if neigh not in visited:
                    visited.add(neigh)
                    visit_order.append(neigh)
                if neigh in back:
                    meet_node = neigh
                    return build_path(front, back, meet_node, visit_order)

        
        b = queue_b.popleft()
        for neigh in clean_graph.get(b, []):
            if neigh not in back:
                back[neigh] = b
                queue_b.append(neigh)
                if neigh not in visited:
                    visited.add(neigh)
                    visit_order.append(neigh)
                if neigh in front:
                    meet_node = neigh
                    return build_path(front, back, meet_node, visit_order)

    return {
        "path": None,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }

def build_path(front, back, meet, visit_order):
    path1 = []
    node = meet
    while node is not None:
        path1.append(node)
        node = front[node]
    path1.reverse()

    path2 = []
    node = back[meet]
    while node is not None:
        path2.append(node)
        node = back[node]

    full_path = path1 + path2
    return {
        "path": full_path,
        "visited": visit_order,
        "steps": len(visit_order),
        "cost": None
    }
