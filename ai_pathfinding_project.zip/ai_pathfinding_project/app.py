from flask import Flask, render_template, request, jsonify

from algorithms.bfs import bfs
from algorithms.dfs import dfs
from algorithms.ucs import ucs
from algorithms.astar import astar
from algorithms.greedy import greedy_best_first
from algorithms.dijkstra import dijkstra
from algorithms.iddfs import iddfs
from algorithms.hill_climbing import hill_climbing
from algorithms.beam import beam_search
from algorithms.bidirectional import bidirectional_search

app = Flask(__name__)

def heuristic(a, b):
    return abs(ord(str(a).upper()) - ord(str(b).upper()))


@app.route("/")
def home():
    return render_template("index.html")

@app.route("/visualize")
def visualize():
    return render_template("visualize.html")

@app.route("/compare")
def compare():
    return render_template("compare.html")

@app.route("/maze")
def maze():
    return render_template("maze.html")

@app.route("/benchmark")
def benchmark():
    return render_template("benchmark.html")  

@app.route("/playground")
def playground():
    return render_template("playground.html")


@app.route("/run_algorithm", methods=["POST"])
def run_algorithm():
    try:
        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400

        data = request.get_json()
        algorithm = data.get("algorithm")
        graph = data.get("graph")
        start = str(data.get("start"))
        goal = str(data.get("goal"))

        if not algorithm or not graph or not start or not goal:
            return jsonify({"error": "Missing required fields"}), 400

        weighted_graph = {}
        for node, edges in graph.items():
            weighted_graph[str(node)] = [(str(e["node"]), int(e["weight"])) for e in edges]

        if algorithm == "BFS":
            result = bfs(graph, start, goal)
        elif algorithm == "DFS":
            result = dfs(graph, start, goal)
        elif algorithm == "UCS":
            result = ucs(weighted_graph, start, goal)
        elif algorithm == "Dijkstra":
            result = dijkstra(weighted_graph, start, goal)
        elif algorithm == "A*":
            result = astar(weighted_graph, start, goal, heuristic)
        elif algorithm == "Greedy":
            result = greedy_best_first(weighted_graph, start, goal, heuristic)
        elif algorithm == "IDDFS":
            result = iddfs(graph, start, goal)
        elif algorithm == "Hill-Climbing":
            result = hill_climbing(graph, start, goal, heuristic)
        elif algorithm == "Beam":
            result = beam_search(graph, start, goal, heuristic, beam_width=2)
        elif algorithm == "Bidirectional":
            result = bidirectional_search(graph, start, goal)
        else:
            return jsonify({"error": "Unknown algorithm"}), 400

        return jsonify(result)

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/solve_maze", methods=["POST"])
def solve_maze():
    try:
        data = request.get_json()
        maze = data.get("maze")
        algo = data.get("algorithm")
        if not maze or not algo:
            return jsonify({"error": "Missing maze or algorithm"}), 400

        rows, cols = len(maze), len(maze[0])
        def node_name(r, c): return f"{r},{c}"

       
        graph = {}
        for r in range(rows):
            for c in range(cols):
                if maze[r][c] == 0:
                    neighbors = []
                    for dr, dc in [(1,0),(-1,0),(0,1),(0,-1)]:
                        nr, nc = r+dr, c+dc
                        if 0<=nr<rows and 0<=nc<cols and maze[nr][nc]==0:
                            neighbors.append({"node": node_name(nr,nc), "weight":1})
                    graph[node_name(r,c)] = neighbors

        start_node = node_name(0,0)
        goal_node = node_name(rows-1, cols-1)

       
        path_nodes = []
        weighted_graph = {k:[(e["node"],e["weight"]) for e in v] for k,v in graph.items()}

        if algo=="BFS":
            path_nodes = bfs(graph,start_node,goal_node)
        elif algo=="DFS":
            path_nodes = dfs(graph,start_node,goal_node)
        elif algo=="UCS":
            path_nodes = ucs(weighted_graph,start_node,goal_node)
        elif algo=="Dijkstra":
            path_nodes = dijkstra(weighted_graph,start_node,goal_node)
        elif algo=="A*":
            path_nodes = astar(weighted_graph,start_node,goal_node,heuristic)
        elif algo=="Greedy":
            path_nodes = greedy_best_first(weighted_graph,start_node,goal_node,heuristic)
        elif algo=="IDDFS":
            path_nodes = iddfs(graph,start_node,goal_node)
        elif algo=="Hill-Climbing":
            path_nodes = hill_climbing(graph,start_node,goal_node,heuristic)
        elif algo=="Beam":
            path_nodes = beam_search(graph,start_node,goal_node,heuristic,beam_width=2)
        elif algo=="Bidirectional":
            path_nodes = bidirectional_search(graph,start_node,goal_node)

     
        path = []
        for n in path_nodes:
            r,c = map(int, n.split(","))
            path.append([r,c])

        return jsonify({"path": path})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/benchmark_algorithm", methods=["POST"])
def benchmark_algorithm():
    try:
        data = request.get_json()
        graph = data.get("graph")
        algorithms = data.get("algorithms") 

        if not graph or not algorithms:
            return jsonify({"error": "Missing graph or algorithms"}), 400

        results = {}
        weighted_graph = {}
        for node, edges in graph.items():
            weighted_graph[str(node)] = [(str(e["node"]), int(e["weight"])) for e in edges]

        for algo in algorithms:
            start = "A"
            goal = "D"
            if algo=="BFS":
                results[algo] = bfs(graph,start,goal)
            elif algo=="DFS":
                results[algo] = dfs(graph,start,goal)
            elif algo=="UCS":
                results[algo] = ucs(weighted_graph,start,goal)
            elif algo=="Dijkstra":
                results[algo] = dijkstra(weighted_graph,start,goal)
            elif algo=="A*":
                results[algo] = astar(weighted_graph,start,goal,heuristic)
            elif algo=="Greedy":
                results[algo] = greedy_best_first(weighted_graph,start,goal,heuristic)
            elif algo=="IDDFS":
                results[algo] = iddfs(graph,start,goal)
            elif algo=="Hill-Climbing":
                results[algo] = hill_climbing(graph,start,goal,heuristic)
            elif algo=="Beam":
                results[algo] = beam_search(graph,start,goal,heuristic,beam_width=2)
            elif algo=="Bidirectional":
                results[algo] = bidirectional_search(graph,start,goal)
            else:
                results[algo] = {"error":"Unknown Algorithm"}

        return jsonify(results)

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
