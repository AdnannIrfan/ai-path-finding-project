function runAlgorithm() {
    const graphText = document.getElementById("graphInput").value.trim();
    const start = document.getElementById("startNode").value.trim();
    const goal = document.getElementById("goalNode").value.trim();
    const algo = document.getElementById("algoSelect").value;

    if (!graphText || !start || !goal) {
        alert("Please enter graph, start node, and goal node.");
        return;
    }

    let graph;
    try {
        graph = JSON.parse(graphText);
    } catch (e) {
        alert("Invalid JSON graph. Example format:\n" +
            '{\n' +
            '  "A": [{"node": "B", "weight": 1}, {"node": "C", "weight": 4}],\n' +
            '  "B": [{"node": "C", "weight": 2}, {"node": "D", "weight": 5}],\n' +
            '  "C": [{"node": "D", "weight": 1}],\n' +
            '  "D": []\n' +
            '}'
        );
        return;
    }

    fetch("/run_algorithm", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({
            algorithm: algo,
            graph: graph,
            start: start,
            goal: goal
        })
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            document.getElementById("outputBox").innerText = "Error: " + data.error;
        } else {
            document.getElementById("outputBox").innerText = JSON.stringify(data, null, 2);
        }
    })
    .catch(err => {
        document.getElementById("outputBox").innerText = "Request failed: " + err;
    });
}
